//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main{
    public static void main(String[] args) {

        CodaCondivisa cc = new CodaCondivisa();

        Produttore threadProduttore1 = new Produttore(cc);
        Consumatore threadConsumatore1 = new Consumatore(cc);

        for(int i=0; i<10; i++) {

            threadProduttore1.start();
            threadConsumatore1.start();

        }


    }
}