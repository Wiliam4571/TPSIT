import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;

public class Consumatore {

    CodaCondivisa codaCondivisa;

    public Consumatore(CodaCondivisa codaCondivisa) {
        this.codaCondivisa = codaCondivisa;
    }

    public void start(){

        codaCondivisa.leggi();

    }

}
