import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;
import java.util.Random;

public class Produttore extends Thread {

    CodaCondivisa codaCondivisa;

    public Produttore(CodaCondivisa codaCondivisa) {
        this.codaCondivisa = codaCondivisa;
    }

    public void start() {

        codaCondivisa.scrivi();

    }


}
