import java.util.*;
import java.util.concurrent.Semaphore;

public class CodaCondivisa {

    Queue<Integer> codaCondivisa = new Queue<Integer>() {
        @Override
        public boolean add(Integer integer) {
            ls.addLast(integer);
            return true;
        }

        @Override
        public boolean offer(Integer integer) {
            return false;
        }

        @Override
        public Integer remove() {
            return 0;
        }

        @Override
        public Integer poll() {
            return ls.removeFirst();
        }

        @Override
        public Integer element() {
            return 0;
        }

        @Override
        public Integer peek() {
            return 0;
        }

        @Override
        public int size() {
            return 0;
        }

        @Override
        public boolean isEmpty() {
            return false;
        }

        @Override
        public boolean contains(Object o) {
            return false;
        }

        @Override
        public Iterator<Integer> iterator() {
            return null;
        }

        @Override
        public Object[] toArray() {
            return new Object[0];
        }

        @Override
        public <T> T[] toArray(T[] ts) {
            return null;
        }

        @Override
        public boolean remove(Object o) {
            return false;
        }

        @Override
        public boolean containsAll(Collection<?> collection) {
            return false;
        }

        @Override
        public boolean addAll(Collection<? extends Integer> collection) {
            return false;
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            return false;
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            return false;
        }

        @Override
        public void clear() {

        }
    };

    ArrayList<Integer> ls = new ArrayList<>();


    int numeroElementi = 0;
    Semaphore semaphore = new Semaphore(1);
    Semaphore risorsaVuota = new Semaphore(5);  //indica se la risorsa è vuota
    Semaphore risorsaPiena = new Semaphore(0);  //indica se la risorsa è presente

    int numeroElementiProdotti=0;
    int numeroElementiConsumati=0;


    public void scrivi() {
        
            try {
                

                risorsaVuota.acquire(); //aspetta che ci sia spazzio nella coda
                
                semaphore.acquire();    //blocca l'accesso al consumatore
                
                if(numeroElementiProdotti<10) {

                    Random r = new Random();
                    codaCondivisa.add(r.nextInt(1, 101));
                    numeroElementi++;
                    numeroElementiProdotti++;

                    risorsaPiena.release();
                }
                else {
                    System.out.println("numero elementi prodotti max");
                    risorsaVuota.release();
                }
                
                semaphore.release();
                

               
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

    }

    public void leggi(){
        

            try {

                risorsaPiena.acquire(); //aspetta che ci siano elementi nella risorsa
                
                semaphore.acquire(); //blocca l'accesso al produttore

                if(numeroElementiConsumati<10) {

                    System.out.println(codaCondivisa.poll());

                    numeroElementi--;
                    numeroElementiConsumati++;

                    risorsaVuota.release();
                }
                else {
                    System.out.println("numero elementi consumati max");
                    risorsaPiena.release();

                }

                semaphore.release();


                
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }


    }

}
